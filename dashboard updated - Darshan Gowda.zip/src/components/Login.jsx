import React, { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import bgImage from "../assets/bg.jpeg";

export const Login = ({ setIsAuthenticated }) => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const navigate = useNavigate();

  const handleLogin = (e) => {
    e.preventDefault();
    if (email === "admin" && password === "admin") {
      setIsAuthenticated(true);
      navigate("/dashboard");
    } else {
      setError("Invalid credentials! Try again.");
    }
  };

  return (
    <div className="relative flex items-center justify-center h-screen p-6">
      <div
        className="absolute inset-0 bg-center bg-cover"
        style={{
          backgroundImage: `url(${bgImage})`,
          filter: "brightness(50%)",
        }}
      ></div>                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              

      <div
        className="relative w-full max-w-md p-8 rounded-lg shadow-xl bg-opacity-60 animate-slide-up backdrop-blur-lg"
        style={{ filter: "brightness(100%)" }}
      >
        <h1 className="mb-6 text-3xl font-bold text-center text-white">Login</h1>

        <button className="flex items-center justify-center w-full gap-3 p-3 mb-6 text-white bg-gray-900 rounded-lg hover:bg-gray-800">
          <img src="https://www.google.com/favicon.ico" alt="Google" className="w-6 h-6" />
          Continue with Google </button>

        <div className="relative mb-6">
          <div className="absolute inset-0 flex items-center">
            <div className="w-full border-t border-gray-600"></div>
          </div>
          <div className="relative flex justify-center text-lg">
            <span className="px-2 text-gray-400 ">or sign in with</span>
          </div>
        </div>

        {error && <p className="mb-4 text-center text-red-500">{error}</p>}

        <form className="space-y-5" onSubmit={handleLogin}>
          <div>
            <input
              type="text"
              placeholder="Username"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full p-3 text-lg text-white border border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div>
            <input
              type="password"
              placeholder="Password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full p-3 text-lg text-white border border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div className="flex items-center justify-between text-white">
            <label className="flex items-center">
              <input type="checkbox" className="mr-2" />
              <span className="text-lg">Keep me signed in</span>
            </label>
            <Link to="/forgot-password" className="text-lg text-blue-400 hover:underline">
              Forgot Password?
            </Link>
          </div>

          <button className="w-full p-3 text-lg font-semibold text-white bg-blue-600 rounded-lg hover:bg-blue-500">
            Login
          </button>
        </form>

        <p className="mt-6 text-lg text-center text-gray-400">
          Don't have an account?{' '}
          <Link to="/signup" className="text-blue-400 hover:underline">
            Sign up here
          </Link>
        </p>
      </div>
    </div>
  );
};
