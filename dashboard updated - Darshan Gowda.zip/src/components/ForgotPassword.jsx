import React from "react";
import { Link } from "react-router-dom";
import bgImage from "../assets/bg.jpeg"; // import the background image

export const ForgotPassword = () => {
  return (
    <div className="relative flex items-center justify-center min-h-screen p-6 bg-gray-900">
      <div
        className="absolute inset-0 bg-center bg-cover"
        style={{
          backgroundImage: `url(${bgImage})`,
          filter: "brightness(50%)",
        }}
      ></div>

      <div
        className="relative w-full max-w-md p-8 rounded-lg shadow-xl bg-opacity-60 animate-slide-up backdrop-blur-lg"
        style={{ filter: "brightness(100%)" }}
      >
        <h1 className="mb-4 text-3xl font-bold text-center text-white">Forgot Password</h1>
        <p className="mb-6 text-lg text-center text-gray-400">
          Enter your registered email. We'll send a password reset link.
        </p>

        <form className="space-y-5">
          <div>
            <input
              type="email"
              placeholder="Email Address"
              className="w-full p-3 text-lg text-white border border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <button className="w-full p-3 text-lg font-semibold text-white bg-gray-600 rounded-lg hover:bg-gray-500">
            Submit
          </button>
        </form>

        <p className="mt-6 text-lg text-center text-gray-400">
          Remember your password?{' '}
          <Link to="/login" className="text-blue-400 hover:underline">
            Log in here
          </Link>
        </p>
      </div>
    </div>
  );
};
